# Livro-Introdutorio-R
Livro que introduz os principais comandos em R, em português.
